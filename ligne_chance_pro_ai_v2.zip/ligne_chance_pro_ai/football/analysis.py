from engine.value import evaluate_market
from football.markets import FOOTBALL_MARKETS

def analyze_markets(market: str, odds: float, probability: float) -> dict:
    return evaluate_market(market, odds, probability)

def available_market_families() -> dict:
    return FOOTBALL_MARKETS
