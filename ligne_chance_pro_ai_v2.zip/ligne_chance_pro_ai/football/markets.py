FOOTBALL_MARKETS = {
    "resultat": ["1X2", "double chance", "remboursé si nul", "handicap européen", "handicap asiatique"],
    "buts": ["plus/moins buts", "total buts équipe", "les deux équipes marquent", "équipe marque", "score exact"],
    "mi_temps": ["résultat mi-temps", "plus/moins buts mi-temps", "mi-temps/fin de match"],
    "joueurs": ["buteur", "passeur décisif", "tirs", "tirs cadrés", "passes"],
    "statistiques": ["corners", "cartons", "fautes", "hors-jeu", "possession"],
}
